#ifndef DISJOINTSET_H
#define DISJOINTSET_H

#include <cstdint>
#include <stdexcept>

class DisjointSet {
public:
    DisjointSet(uint32_t n);
    ~DisjointSet();
    
    void join(uint32_t a,uint32_t b);
    uint32_t find(uint32_t a);
    
private:
    uint32_t
        nElements,
        *parent;
    uint8_t
        *rank;
};

#endif

